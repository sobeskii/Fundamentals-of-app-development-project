package ktu.edu.projektas.app.data

 class Notification (
        var firebaseId: String = "",
        val text: String ="",
        val date: String = "",
        val userid : String = ""
        )