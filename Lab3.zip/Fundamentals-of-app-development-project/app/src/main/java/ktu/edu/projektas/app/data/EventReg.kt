package ktu.edu.projektas.app.data

 class EventReg (
        val userid: String ="",
        val eventid : String =""
        )