package ktu.edu.projektas.app.data

// user's class
class User (
    val firstName: String ="",
    val lastName: String="",
    val email: String="",
    val role: String="",
    val group: String="",
    val firebaseId:String="",
    )
